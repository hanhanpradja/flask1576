class Mobil():
    def __init__(self) -> None:
        self.roda = 4
        self.pintu = 4
        self.ac = 'ya'
        self.stir = 'ya'
        self.jarak = 0
    
    # method
    def maju(self):
        self.jarak += 5

class Lambo(Mobil):
    def __init__(self) -> None:
        super().__init__()
        self.pintu = 2
        